<div class="container">

	<!-------------------------------------------BILLETES AGREGADOS------------------------------------------------------------>
	<?php if(!empty($sugerencia)): ?>		

			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">							
					<h5><?php echo $sugerencia->descripcion ?></h5>
				</div>
				
			</div>
	<?php endif; ?>	
</div>

<!-------------------------------------------BILLETES AGREGADOS------------------------------------------------------------>

<!----------------------------------------------------SECCION DE PAGOS---------------------------------------------->	
						
