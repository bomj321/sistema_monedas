<div class="form-group">
	<label for="opciones_especialesm" class="col-sm-12 col-xs-12 col-md-2 col-lg-2  control-label">Nueva Opci&oacute;n</label>								
	 <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
		 	<input required type="text" class="form-control" placeholder="Opcion Nueva" id="opciones_especialesm" name="opciones_especialesm[]">		 	
	</div>

	 <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
		 	<button class="btn btn-warning eliminar">Eliminar Opcion</button>
	</div>
					
</div>